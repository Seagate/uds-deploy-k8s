#!/usr/bin/python3

import sys
import os

from ast import literal_eval
from udx_ds.utils.path.path_utils import join

print("DMX Object processing script")

status = 'PASSED'
reason = 'Good'
tags = []

udxman_finfo = ''
udxman_finfo_dict = None
if len(sys.argv) >= 4:
    udxman_finfo = sys.argv[3]
    udxman_finfo_dict = literal_eval(udxman_finfo)


data_path = ''
if len(sys.argv) == 5:
    data_path = sys.argv[4]


if sys.argv[2] == 'INGEST' and udxman_finfo_dict is not None and data_path != '':
    file_path = join(data_path, udxman_finfo_dict['fileName'])
    if os.path.exists(file_path):
        with open(file_path, 'r') as infile:
            read_line = infile.readline()
            if 'right turn' == read_line:
                tags = ['RIGHT_TURN']
            if 'left turn' == read_line:
                tags = ['LEFT_TURN']

if sys.argv[2] == 'EXPORT' and udxman_finfo_dict is not None:
    if udxman_finfo_dict.get('customInfo', None) is not None:
        if udxman_finfo_dict['customInfo']['tags'][0] != 'RIGHT_TURN':
            status = 'IGNORE'
    if udxman_finfo_dict.get('customInfo', None) is None:
        status = 'IGNORE'

result = {
    "status": status,
    "reason": reason,
    "tags": tags
}

print(result)

